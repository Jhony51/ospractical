/*2.2 Implement the C program in which main program accepts an integer array. Main program uses the fork 
system call to create a new process called a child process. Parent process sorts an integer array and passes 
the sorted array to child process through the command line arguments of execve system call. The child 
process uses execve system call to load new program that uses this sorted array for performing the binary 
search to search the item in the array.*/


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

// Bubble sort function
void bubbleSort(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

int main() {
    int n;
    printf("Enter number of elements: ");
    scanf("%d", &n);

    int arr[n];
    printf("Enter %d integers: ", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    // Sort the array in parent
    bubbleSort(arr, n);
    printf("Parent: Sorted array: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    pid_t pid = fork();

    if (pid < 0) {
        perror("Fork failed");
        exit(1);
    }
    // Child process
    else if (pid == 0) {
        printf("\nChild process created (PID: %d)\n", getpid());

        int key;
        printf("Enter element to search: ");
        scanf("%d", &key);

        char *args[n + 3];      // program name + n elements + key + NULL
        args[0] = "./child";    // child program name

        for (int i = 0; i < n; i++) {
            char *num = malloc(10);
            sprintf(num, "%d", arr[i]);
            args[i + 1] = num;
        }

        char *searchKey = malloc(10);         // Add search key
        sprintf(searchKey, "%d", key);
        args[n + 1] = searchKey;

        args[n + 2] = NULL;       // Null terminate the argument list

        execve(args[0], args, NULL);        // Execute child_search program

        perror("execve failed");       // If execve returns, it failed

        exit(1);
    }

    else {
        wait(NULL);
        printf("\nParent: Child process finished.\n");      // Parent process waits for child
    }

    return 0;
}
