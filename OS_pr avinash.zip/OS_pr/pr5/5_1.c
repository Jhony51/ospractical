#include <stdio.h>

#define MAX_P 10   // maximum number of processes
#define MAX_R 10   // maximum number of resources

int p, r;  // actual number of processes and resources
int alloc[MAX_P][MAX_R];  // Allocation Matrix
int max[MAX_P][MAX_R];    // Maximum Need Matrix
int avail[MAX_R];         // Available Resources
int need[MAX_P][MAX_R];   // Need Matrix

// Function to take input for Allocation, Maximum, and Available matrices
void takeInput() {
    printf("Enter number of processes: ");
    scanf("%d", &p);
    printf("Enter number of resources : ");
    scanf("%d", &r);

    printf("\nEnter Allocation Matrix (%d x %d):\n", p, r);
    for (int i = 0; i < p; i++)
        for (int j = 0; j < r; j++)
            scanf("%d", &alloc[i][j]);

    printf("\nEnter Maximum Matrix (%d x %d):\n", p, r);
    for (int i = 0; i < p; i++)
        for (int j = 0; j < r; j++)
            scanf("%d", &max[i][j]);

    printf("\nEnter Available Resources for %d types: ", r);
    for (int i = 0; i < r; i++)
        scanf("%d", &avail[i]);
}

// Function to calculate Need matrix = Max - Allocation
void calculateNeed() {
    for (int i = 0; i < p; i++)
        for (int j = 0; j < r; j++)
            need[i][j] = max[i][j] - alloc[i][j];
}

// Function to check if system is in safe state
int isSafe() {
    int finish[MAX_P] = {0};
    int safeSeq[MAX_P];
    int work[MAX_R];

    for (int i = 0; i < r; i++)
        work[i] = avail[i];  // initially available

    int count = 0;

    while (count < p) {
        int found = 0;
        for (int i = 0; i < p; i++) {
            if (!finish[i]) {
                int canAllocate = 1;
                for (int j = 0; j < r; j++) {
                    if (need[i][j] > work[j]) {
                        canAllocate = 0;
                        break;
                    }
                }

                if (canAllocate) {
                    for (int j = 0; j < r; j++)
                        work[j] += alloc[i][j];
                    safeSeq[count++] = i;
                    finish[i] = 1;
                    found = 1;
                }
            }
        }

        if (!found) {
            printf("\nSystem is NOT in a Safe State!\n");
            return 0;
        }
    }

    printf("\nSystem is in a Safe State.\nSafe Sequence: ");
    for (int i = 0; i < p; i++)
        printf("P%d ", safeSeq[i]);
    printf("\n");
    return 1;
}

// Function to handle a resource request from a process
void resourceRequest() {
    int req[MAX_R], proc;
    printf("Enter process number (0 to %d): ", p - 1);
    scanf("%d", &proc);

    printf("Enter request for %d resources: ", r);
    for (int i = 0; i < r; i++)
        scanf("%d", &req[i]);

    for (int i = 0; i < r; i++) {
        if (req[i] > need[proc][i]) {
            printf("Error: Process has exceeded its maximum claim!\n");
            return;
        }
        if (req[i] > avail[i]) {
            printf("Resources not available, process must wait.\n");
            return;
        }
    }

    // Pretend to allocate
    for (int i = 0; i < r; i++) {
        avail[i] -= req[i];
        alloc[proc][i] += req[i];
        need[proc][i] -= req[i];
    }

    if (isSafe()) {
        printf("Request can be granted safely.\n");
    } else {
        printf("Request CANNOT be granted safely — rolling back.\n");
        for (int i = 0; i < r; i++) {
            avail[i] += req[i];
            alloc[proc][i] -= req[i];
            need[proc][i] += req[i];
        }
    }
}

int main() {
    printf("\n--- BANKER'S ALGORITHM ---\n");

    takeInput();
    calculateNeed();

    int choice;
    while (1) {
        printf("\n\n--- BANKER'S ALGORITHM MENU ---");
        printf("\n1. Display Need Matrix");
        printf("\n2. Check for Safe State");
        printf("\n3. Make a Resource Request");
        printf("\n4. Exit");
        printf("\nEnter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("\nNeed Matrix:\n");
                for (int i = 0; i < p; i++) {
                    for (int j = 0; j < r; j++)
                        printf("%d ", need[i][j]);
                    printf("\n");
                }
                break;
            case 2:
                isSafe();
                break;
            case 3:
                resourceRequest();
                break;
            case 4:
                return 0;
            default:
                printf("Invalid choice!\n");
        }
    }
}
