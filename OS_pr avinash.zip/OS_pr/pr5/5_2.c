#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAX_P 10
#define MAX_R 10

int P, R; // Number of processes and resources
int Allocation[MAX_P][MAX_R];
int Max[MAX_P][MAX_R];
int Available[MAX_R];
int Need[MAX_P][MAX_R];

// Function to read input from state.txt
void takeInputFromFile() {
    FILE *fp = fopen("state.txt", "r");
    if (!fp) {
        printf("Error: Could not open state.txt\n");
        return;
    }

    // Read number of processes and resources
    fscanf(fp, "%*s %*s %*s %d", &P); // skip "Number of Processes" text
    fscanf(fp, "%*s %*s %*s %d", &R); // skip "Number of Resources" text

    // Read Allocation matrix
    for (int i = 0; i < P; i++)
        for (int j = 0; j < R; j++)
            fscanf(fp, "%d", &Allocation[i][j]);

    // Read Max matrix
    for (int i = 0; i < P; i++)
        for (int j = 0; j < R; j++)
            fscanf(fp, "%d", &Max[i][j]);

    // Read Available resources
    for (int j = 0; j < R; j++)
        fscanf(fp, "%d", &Available[j]);

    fclose(fp);
}

// Calculate Need matrix
void calculateNeed() {
    for (int i = 0; i < P; i++)
        for (int j = 0; j < R; j++)
            Need[i][j] = Max[i][j] - Allocation[i][j];
}

// Print current system state
void printState() {
    printf("\nAllocation Matrix:\n");
    for (int i = 0; i < P; i++) {
        for (int j = 0; j < R; j++)
            printf("%d ", Allocation[i][j]);
        printf("\n");
    }

    printf("\nMax Matrix:\n");
    for (int i = 0; i < P; i++) {
        for (int j = 0; j < R; j++)
            printf("%d ", Max[i][j]);
        printf("\n");
    }

    printf("\nNeed Matrix:\n");
    for (int i = 0; i < P; i++) {
        for (int j = 0; j < R; j++)
            printf("%d ", Need[i][j]);
        printf("\n");
    }

    printf("\nAvailable Resources:\n");
    for (int j = 0; j < R; j++)
        printf("%d ", Available[j]);
    printf("\n");
}

// Check safe state
bool isSafe() {
    int work[MAX_R];
    bool finish[MAX_P] = {false};
    int safeSeq[MAX_P];
    int count = 0;

    for (int j = 0; j < R; j++)
        work[j] = Available[j];

    while (count < P) {
        bool found = false;
        for (int i = 0; i < P; i++) {
            if (!finish[i]) {
                int j;
                for (j = 0; j < R; j++)
                    if (Need[i][j] > work[j])
                        break;

                if (j == R) {
                    for (int k = 0; k < R; k++)
                        work[k] += Allocation[i][k];
                    finish[i] = true;
                    safeSeq[count++] = i;
                    found = true;
                }
            }
        }
        if (!found) {
            printf("\nSystem is NOT in a Safe State!\n");
            return false;
        }
    }

    printf("\nSystem is in a Safe State.\nSafe Sequence: ");
    
    for (int i = 0; i < P; i++){
        printf("P%d ", safeSeq[i]);
    }

    printf("\n");
    return true;
}

// Handle a resource request
void resourceRequest() {
    int pid, request[MAX_R];
    printf("\nEnter process number (0 to %d): ", P - 1);
    scanf("%d", &pid);

    if (pid < 0 || pid >= P) {
        printf("Invalid process ID.\n");
        return;
    }

    printf("Enter request vector (%d values): ", R);
    for (int j = 0; j < R; j++)
        scanf("%d", &request[j]);

    // Check request <= Need
    for (int j = 0; j < R; j++)
        if (request[j] > Need[pid][j]) {
            printf("Error: Process P%d has exceeded its maximum claim.\n", pid);
            return;
        }

    // Check request <= Available
    for (int j = 0; j < R; j++)
        if (request[j] > Available[j]) {
            printf("Resources not available, process must wait.\n");
            return;
        }

    // Pretend allocation
    for (int j = 0; j < R; j++) {
        Available[j] -= request[j];
        Allocation[pid][j] += request[j];
        Need[pid][j] -= request[j];
    }

    // Check safe state
    if (isSafe()) {
        printf("Request can be granted safely.\n");
    } else {
        printf("Request CANNOT be granted safely — rolling back.\n");
        for (int j = 0; j < R; j++) {
            Available[j] += request[j];
            Allocation[pid][j] -= request[j];
            Need[pid][j] += request[j];
        }
    }
}

int main() {
    takeInputFromFile();  // read input from state.txt
    calculateNeed();
    printState();

    printf("\n--- Initial Safety Check ---\n");
    if (isSafe()) {
        printf("\n--- Now Demonstrate Resource Request ---\n");
        resourceRequest();
    } else {
        printf("Initial state is UNSAFE. Cannot proceed with requests.\n");
    }

    return 0;
}
