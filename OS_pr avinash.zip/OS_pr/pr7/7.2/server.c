#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>

#define SHM_SIZE 1024

struct new_shm {
    int flag;           
    char msg[SHM_SIZE];
};

int main() {
    key_t key = ftok("shmfile", 65);
    
    if (key == -1) {
        perror("ftok");
        exit(1);
    }
    
    int shmid = shmget(key, sizeof(struct new_shm), 0666 | IPC_CREAT);
    
    if (shmid == -1) {
        perror("shmget");
        exit(1);
    }
    
    struct new_shm *shm = (struct new_shm *) shmat(shmid, NULL, 0);
    
    if (shm == (struct new_shm *) -1) {
        perror("shmat");
        exit(1);
    }
    
    shm->flag = 0; 
    
    printf("Server ready. Type messages (type 'exit' to stop):\n");
    
    while (1) {
        if (shm->flag == 0) {  
            printf("Enter message: ");
            fgets(shm->msg, SHM_SIZE, stdin);
            shm->flag = 1;  
            
            if (strcmp(shm->msg, "exit\n") == 0) {
                printf("\nShared memory destroyed.....\n");
                break;
            }
        }
    }
    
    shmdt(shm);
    shmctl(shmid, IPC_RMID, NULL);
    
    return 0;
}