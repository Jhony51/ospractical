#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define MAX 100

struct message {
    long msg_type;       // Message type (fixed)
    char msg_text[MAX];  // Message content
};

int main() {
    key_t key = ftok("msgqueuekey", 65); // unique key
    int msgid = msgget(key, 0666 | IPC_CREAT);
    struct message msg;

    msg.msg_type = 1; // fixed message type

    printf("Enter messages to send (type 'exit' to quit):\n");

    while (1) {
        printf("Message: ");
        fgets(msg.msg_text, MAX, stdin);
        int index = strcspn(msg.msg_text, "\n");
        msg.msg_text[index] = '\0'; // remove newline

        
        msgsnd(msgid, &msg, sizeof(msg.msg_text), 0);
        printf("Message sent!\n");
        
        if (strcmp(msg.msg_text, "exit") == 0) {
            break;
        }
    }

    printf("Sender exiting.\n");
    return 0;
}
