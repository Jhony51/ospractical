#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define MAX 100

struct message {
    long msg_type;
    char msg_text[MAX];
};

void toUpperCase(char *str) {
    for (int i = 0; str[i]; i++)
        str[i] = toupper(str[i]);
}

int main() {
    key_t key = ftok("msgqueuekey", 65);
    int msgid = msgget(key, 0666 | IPC_CREAT);
    struct message msg;

    printf("Receiver started. Reading messages...\n");

    while (1) {
        // Receive message of any type (0 means first in queue)
        msgrcv(msgid, &msg, sizeof(msg.msg_text), 0, 0);

        if (strcmp(msg.msg_text, "exit") == 0) {
            break;
        }

        toUpperCase(msg.msg_text);
        printf("Received (uppercase): %s\n", msg.msg_text);
    }

    // Cleanup
    msgctl(msgid, IPC_RMID, NULL);
    printf("Receiver exiting. Message queue deleted.\n");
    return 0;
}
