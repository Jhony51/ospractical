// #include <stdio.h>
// #include <stdlib.h>
// #include <pthread.h>
// #include <semaphore.h>
// #include <unistd.h>

// #define MAX_CHAIRS 3   // number of waiting chairs in the hallway
// #define MAX_STUDENTS 10 // number of students

// sem_t students_sem;     // counts number of students waiting
// sem_t ta_sem;           // TA signal semaphore
// pthread_mutex_t mutex;  // mutex to protect waiting_students variable

// int waiting_students = 0; // number of students currently waiting

// // ---------------- TA Thread ----------------
// void *ta_work(void *arg) {
//     while (1) {
//         // Wait until a student arrives (if no student, TA sleeps)
//         sem_wait(&students_sem);

//         // A student is ready, now try to acquire lock and help them
//         pthread_mutex_lock(&mutex);
//         waiting_students--;
//         printf("TA starts helping a student. Students waiting: %d\n", waiting_students);
//         pthread_mutex_unlock(&mutex);

//         // Signal that TA is now ready to help student
//         sem_post(&ta_sem);

//         // Simulate time taken to help the student
//         sleep(rand() % 3 + 1);

//         printf("TA finished helping a student and checks for next one.\n");
//     }
//     return NULL;
// }



// // ---------------- Student Thread ----------------
// void *student_work(void *arg) {
//     int id = *(int *)arg;

//     while (1) {
//         pthread_mutex_lock(&mutex);
//         if (waiting_students < MAX_CHAIRS) {
//             waiting_students++;
//             printf("Student %d waiting. Students waiting: %d\n", id, waiting_students);

//             // Notify TA that a student is waiting
//             sem_post(&students_sem);
//             pthread_mutex_unlock(&mutex);

//             // Wait for TA to help
//             sem_wait(&ta_sem);
//             printf("Student %d is getting help from the TA.\n", id);
//         } else {
//             pthread_mutex_unlock(&mutex);
//             printf("Student %d found no empty chair. Will come back later.\n", id);
//         }
//         sleep(rand() % 5 + 1);
//     }
//     return NULL;
// }


// // ---------------- Main ----------------
// int main() {
//     pthread_t ta;
//     pthread_t students[MAX_STUDENTS];
//     int student_ids[MAX_STUDENTS];

//     srand(time(NULL));

//     // Initialize synchronization primitives
//     sem_init(&students_sem, 0, 0);  // initially no students waiting
//     sem_init(&ta_sem, 0, 0);        // TA is sleeping initially
//     pthread_mutex_init(&mutex, NULL);

//     // Create TA thread
//     pthread_create(&ta, NULL, ta_work, NULL);

//     // Create student threads
//     for (int i = 0; i < MAX_STUDENTS; i++) {
//         student_ids[i] = i + 1;
//         pthread_create(&students[i], NULL, student_work, &student_ids[i]);
//     }

//     // Join threads (infinite loop, so not actually reached)
//     pthread_join(ta, NULL);
//     for (int i = 0; i < MAX_STUDENTS; i++)
//         pthread_join(students[i], NULL);

//     // Cleanup (never reached here)
//     sem_destroy(&students_sem);
//     sem_destroy(&ta_sem);
//     pthread_mutex_destroy(&mutex);

//     return 0;
// }


#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define NUM_STUDENTS 5     // number of students
#define NUM_CHAIRS 3       // number of waiting chairs

sem_t students;            // counts waiting students
sem_t ta;                  // whether TA is ready to help
pthread_mutex_t mutex;     // protects shared variable chairsCount
int chairsCount = 0;       // number of waiting students

// TA thread function
void *ta_function(void *arg) {
    while (1) {
        // TA sleeps if there are no students
        sem_wait(&students);  // wait until a student arrives

        // Lock to modify shared resource
        pthread_mutex_lock(&mutex);
        chairsCount--;  // one student leaves waiting chair to get help
        printf("TA is helping a student. Waiting students = %d\n", chairsCount);
        pthread_mutex_unlock(&mutex);

        // TA is now ready to help a student
        sem_post(&ta);

        // Simulate helping time
        sleep(2);
        printf("TA finished helping a student.\n");
    }
}

// Student thread function
void *student_function(void *arg) {
    int id = *(int *)arg;

    while (1) {
        printf("Student %d is programming.\n", id);
        sleep(rand() % 5 + 1);  // programming before needing help

        pthread_mutex_lock(&mutex);
        if (chairsCount < NUM_CHAIRS) {
            chairsCount++;
            printf("Student %d is waiting. Waiting students = %d\n", id, chairsCount);

            // Notify TA that a student is waiting
            sem_post(&students);
            pthread_mutex_unlock(&mutex);

            // Wait until TA is ready
            sem_wait(&ta);
            printf("Student %d is getting help from the TA.\n", id);
        } else {
            // No chairs available, student leaves
            printf("Student %d found no empty chair. Will try later.\n", id);
            pthread_mutex_unlock(&mutex);
        }

        // Simulate time after getting help or leaving
        sleep(1);
    }

    pthread_exit(NULL);
}

int main() {
    pthread_t taThread;
    pthread_t studentThreads[NUM_STUDENTS];
    int id[NUM_STUDENTS];

    // Initialize semaphores and mutex
    sem_init(&students, 0, 0);
    sem_init(&ta, 0, 0);
    pthread_mutex_init(&mutex, NULL);

    // Create TA thread
    pthread_create(&taThread, NULL, ta_function, NULL);

    // Create student threads
    for (int i = 0; i < NUM_STUDENTS; i++) {
        id[i] = i + 1;
        pthread_create(&studentThreads[i], NULL, student_function, &id[i]);
    }

    // Join threads (never actually reached due to infinite loop)
    pthread_join(taThread, NULL);
    for (int i = 0; i < NUM_STUDENTS; i++)
        pthread_join(studentThreads[i], NULL);

    // Cleanup (unreachable in this example)
    sem_destroy(&students);
    sem_destroy(&ta);
    pthread_mutex_destroy(&mutex);

    return 0;
}
