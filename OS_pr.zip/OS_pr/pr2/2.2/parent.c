#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

// Function to sort array
void sort(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (arr[i] > arr[j]) {
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
}

int main() {
    int n;
    printf("Enter number of elements: ");
    scanf("%d", &n);

    int arr[n];
    printf("Enter %d integers: ", n);
    for (int i = 0; i < n; i++)
        scanf("%d", &arr[i]);

    // Sort array
    sort(arr, n);

    printf("Parent: Sorted array: ");
    for (int i = 0; i < n; i++)
        printf("%d ", arr[i]);
    printf("\n");

    pid_t pid = fork();

    if (pid == 0) {
        // Child process
        char *args[n + 3]; //
        args[0] = "./child"; // child program name

        for (int i = 0; i < n; i++) {
            char *num = malloc(10);
            sprintf(num, "%d", arr[i]);
            args[i + 1] = num;
        }

        int key;
        printf("Enter element to search: ");
        scanf("%d", &key);

        char *keyStr = malloc(10);
        sprintf(keyStr, "%d", key);
        args[n + 1] = keyStr;
        args[n + 2] = NULL;

        execve("./child", args, NULL);
        perror("execve failed");
    } 
    else {
        wait(NULL);
        printf("Parent: Child process finished.\n");
    }

    return 0;
}
