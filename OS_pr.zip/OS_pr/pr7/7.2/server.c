// server.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>

int main() {
    // Step 1: Generate a unique key
    key_t key = ftok("shmfile", 65);

    // Step 2: Create shared memory (size 1024 bytes)
    int shmid = shmget(key, 1024, 0666 | IPC_CREAT);

    // Step 3: Attach to the shared memory
    char *str = (char *) shmat(shmid, NULL, 0);

    // Step 4: Write message to shared memory
    printf("Enter a message to write to shared memory: ");
    fgets(str, 1024, stdin);

    // Step 5: Remove newline from message (optional cleanup)
    str[strcspn(str, "\n")] = '\0';

    printf("Data written to shared memory: %s\n", str);

    // Step 6: Wait before detaching (give client time to read)
    printf("Waiting for client to read...\n");
    sleep(10);

    // Step 7: Detach and destroy shared memory
    shmdt(str);
    shmctl(shmid, IPC_RMID, NULL);

    printf("Shared memory detached and deleted.\n");

    return 0;
}
