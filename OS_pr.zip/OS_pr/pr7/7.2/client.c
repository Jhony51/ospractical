// client.c
#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>

int main() {
    // Step 1: Generate the same unique key
    key_t key = ftok("shmfile", 65);

    // Step 2: Locate the shared memory created by the server
    int shmid = shmget(key, 1024, 0666);

    // Step 3: Attach to the shared memory
    char *str = (char *) shmat(shmid, NULL, 0);

    // Step 4: Read and display the message
    printf("Data read from shared memory: %s\n", str);

    // Step 5: Detach from shared memory
    shmdt(str);

    return 0;
}
