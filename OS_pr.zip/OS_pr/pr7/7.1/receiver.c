#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define MAX 100

struct msg_buffer {
    long msg_type;
    char msg_text[MAX];
} message;

void to_uppercase(char *str) {
    for (int i = 0; str[i]; i++)
        str[i] = toupper(str[i]);
}

int main() {
    key_t key;
    int msgid;

    key = ftok("progfile", 65); // same key as sender
    msgid = msgget(key, 0666 | IPC_CREAT); // access message queue

    while (1) {
        msgrcv(msgid, &message, sizeof(message.msg_text), 1, 0); // receive message

        if (strcmp(message.msg_text, "exit") == 0) {
            printf("Receiver exiting...\n");
            msgctl(msgid, IPC_RMID, NULL); // cleanup
            break;
        }

        to_uppercase(message.msg_text);
        printf("Received message (in uppercase): %s\n", message.msg_text);
    }

    return 0;
}
