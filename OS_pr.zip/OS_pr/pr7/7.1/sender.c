#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define MAX 100

struct msg_buffer {
    long msg_type;
    char msg_text[MAX];
} message;

int main() {
    key_t key;
    int msgid;

    key = ftok("progfile", 65); // create unique key
    msgid = msgget(key, 0666 | IPC_CREAT); // create message queue

    while (1) {
        printf("Enter message (or 'exit' to quit): ");
        fgets(message.msg_text, MAX, stdin);
        message.msg_text[strcspn(message.msg_text, "\n")] = '\0'; // remove newline
        message.msg_type = 1; // set message type

        msgsnd(msgid, &message, sizeof(message.msg_text), 0); // send message

        if (strcmp(message.msg_text, "exit") == 0) {
            printf("Sender exiting...\n");
            break;
        }
    }

    return 0;
}


    printf("Sender exiting.\n");
    return 0;
}
